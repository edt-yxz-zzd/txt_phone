document.writeln("<script type=\"text\/javascript\" >BAIDU_CLB_SLOT_ID = \"833257\";<\/script>");
document.writeln("<script type=\"text\/javascript\" src=\"http:\/\/cbjs.baidu.com\/js\/o.js\"><\/script>");

document.writeln("<!-- Baidu Button BEGIN -->");
document.writeln("<script type=\"text\/javascript\" id=\"bdshare_js\" data=\"type=slide&amp;img=0&amp;uid=13724\" ><\/script>");
document.writeln("<script type=\"text\/javascript\" id=\"bdshell_js\"><\/script>");
document.writeln("<script type=\"text\/javascript\">");
document.writeln("	document.getElementById(\"bdshell_js\").src = \"http:\/\/bdimg.share.baidu.com\/static\/js\/shell_v2.js?t=\" + new Date().getHours();");
document.writeln("<\/script>");
document.writeln("<!-- Baidu Button END -->");

document.writeln("<script type=\"text\/javascript\">");
document.writeln("var _bdhmProtocol = ((\"https:\" == document.location.protocol) ? \" https:\/\/\" : \" http:\/\/\");");
document.writeln("document.write(unescape(\"%3Cscript src=\'\" + _bdhmProtocol + \"hm.baidu.com\/h.js%3F0f9ebf9bca176270cf174ef42d3d5c3f\' type=\'text\/javascript\'%3E%3C\/script%3E\"));");
document.writeln("<\/script>");


document.writeln("<span style=\'display:none;\'><script src=\'https://s95.cnzz.com/z_stat.php?id=1254102799&web_id=1254102799\' language=\'JavaScript\'></script></span>");