document.writeln("<script type=\"text\/javascript\">");
document.writeln("var cpro_id = \"u1438146\";");
document.writeln("<\/script>");
document.writeln("<script src=\"http:\/\/cpro.baidustatic.com\/cpro\/ui\/c.js\" type=\"text\/javascript\"><\/script>");