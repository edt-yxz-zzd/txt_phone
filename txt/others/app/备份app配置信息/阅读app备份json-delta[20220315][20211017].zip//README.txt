
注意:
  书架信息:myBookShelf.json
  排序不重要，finalDate才是关键
        (datetime.datetime.fromtimestamp(1647303785952/1000))
        int(datetime.datetime.now().timestamp()*1000)

view /storage/emulated/0/0my_files/tmp/xxx/阅读app备份json/README.txt
  e /sdcard/0my_files/tmp/xxx/阅读app备份json/README.txt
  view /storage/emulated/0/0my_files/tmp/xxx/阅读app备份json/\[20211017]阅读app备份json/myBookShelf.json
  view /mnt/m_external_sd/000edt/0my_files/book_txt/小说天堂txt/小说天堂书名归类-细分类成.txt
  ==>> 备份
    view others/app/备份app配置信息/阅读app备份json-delta[20220315][20211017].zip
    view others/app/备份app配置信息/阅读app备份json.zip
      [20211017]版-基础版
    ---
    cp -r -T /sdcard/0my_files/tmp/xxx/auto/  /storage/emulated/0/0my_files/tmp/xxx/阅读app备份json/[20220314]阅读app备份json/
    view /storage/emulated/0/0my_files/tmp/xxx/auto/myBookShelf.json
    view /storage/emulated/0/0my_files/tmp/xxx/阅读app备份json/\[20220314]阅读app备份json/myBookShelf.json
    阅读app -> 左上角 三横/拖出左侧栏 -> 备份
      ==>> xxx/???.json...
      not ===>> xxx/auto/*
    cd /storage/emulated/0/0my_files/tmp/xxx/
    mkdir /storage/emulated/0/0my_files/tmp/xxx/阅读app备份json/[20220315]阅读app备份json/
    cp -t /storage/emulated/0/0my_files/tmp/xxx/阅读app备份json/[20220315]阅读app备份json/      config.xml myBookSearchHistory.json myBookShelf.json myBookSource.json myTxtChapterRule.json
    view /storage/emulated/0/0my_files/tmp/xxx/阅读app备份json/\[20220315]阅读app备份json/myBookShelf.json
    patch
    diff 阅读app备份json/[20220314]阅读app备份json/myBookShelf.json  阅读app备份json/[20220315]阅读app备份json/myBookShelf.json > /storage/emulated/0/0my_files/tmp/out4diff/阅读.diff.20220315.txt
    view /storage/emulated/0/0my_files/tmp/out4diff/阅读.diff.20220315.txt
    e /storage/emulated/0/0my_files/tmp/xxx/myBookShelf.json
      [20220315]版，由于添加了许多本地txt，需将它们后移
      #deprecated将《明朝好丈夫》居前的部分移动到《太上章》居前。
      将《孙子兵法与三十六计攻略全本》居前的部分移动到《太上章》居前。
        <==>移动《猎艳江湖》..《九章算术》至《弟子规 增广贤文 声律启蒙 幼学琼林》《太上章》之间
    阅读app -> 左上角 三横/拖出左侧栏 -> 恢复
      无效？
      等了几分钟，书架空白刷新，但内容不变！
      view /storage/emulated/0/0my_files/tmp/xxx/auto/myBookShelf.json
        [20220314]版，更老
      备份/恢复 怎么回事？
      似乎应该修改 "finalDate"属性#最后访问时间？
        值越大越晚排行越靠前
        [[[
        《弟子规 增广贤文 声律启蒙 幼学琼林》 "finalDate": 1634426225897,
          猎艳江湖 "finalDate": 1647303785952,
          九章算术 "finalDate": 1647300477838,
          ---改 164730 为 163436
            :.,$s/\<164730/163436
              #已排除了 孙子兵法与三十六计攻略全本
        太上章 "finalDate": 1634358279025,
        ]]]
        成功！！！
          见:阅读app -> 左上角 三横/拖出左侧栏 -> 设置 -> 书架设置.书架排序:按阅读时间排序
    ---
    diff -q 阅读app备份json/[20220314]阅读app备份json/  阅读app备份json/[20220315]阅读app备份json/
      Files 阅读app备份json/[20220314]阅读app备 份json/myBookShelf.json and 阅读app备份json/[20220315]阅读app备份json/myBookShelf.json differ

    diff -q 阅读app备份json/[20211017]阅读app备份json/  阅读app备份json/[20220314]阅读app备份json/
      Files 阅读app备份json/[20211017]阅读app备 份json/config.xml and 阅读app备份json/[20220314]阅读app备份json/config.xml differ
      Files 阅读app备份json/[20211017]阅读app备 份json/myBookShelf.json and 阅读app备份json/[20220314]阅读app备份json/myBookShelf.json differ
        ###不需要 保存那么多 文件
        ###删减，新增 空文件夹 'ref[20211017]' 'ref[20220314]'

    diff 阅读app备份json/[20211017]阅读app备份json/config.xml  阅读app备份json/[20220314]阅读app备份json/config.xml
    ===
    尝试解读:finalDate:1647303785952
    [div 1000 is Python.timestamp]
        (datetime.datetime.fromtimestamp(1647303785952/1000))
            #2022-03-15 08:23:05.952000






阅读
  轻阅 @com.feng.monkeybook
    # 本地txt小说 + 联网书源离线下载
    #https://github.com/gedoor/MyBookshelf ??
    # 可替代 小说阅读器（亮度无法降至零！）
    # 问题是：下载的小说 是 从网页爬的，速度慢，只有25kB/s；质量没保证，一千章就是一千文本文件，1156章*6kB ?=? 17MB by 『du -d 0 -h .』 ???
    #轻阅 离线下载路径: '/sdcard/Android/data/com.feng.monkeybook/files/book_cache/修真者在异世-httpswwwgeilwxcc/00000-第一章  超级散魔.nb'
    #轻阅 书源 文件路径: /sdcard/YueDu/auto/myBookSource.json
      $ ls /sdcard/YueDu/auto/
      config.xml
      myBookSearchHistory.json
      myBookShelf.json
      myBookSource.json
      myTxtChapterRule.json
    轻阅 轻量级阅读工具（不是 轻阅影视）
      旧版:http://m.58xuexi.com/app/v195389.html
      轻阅v10047
        <<== https://www.xiaozhongjishu.com/app/656.html/
          <<== 小众技术工具库:https://www.xiaozhongjishu.com/
  阅读 @com.gedoor.monkeybook
    # 这才是『轻阅』的原版，但没有书源，看来需要从 轻阅 复制 书源，见上面『轻阅 书源 文件路径』
    #
      官网:https://github.com/gedoor/MyBookshelf
          <<== 小众技术工具库:https://www.xiaozhongjishu.com/
    #！！！备份！！！
    #   左上角 竖排三横 -> 备份 [初始化 选择文件夹，以后 默认...]
    #   /sdcard/0my_files/tmp/xxx/
        $ ls /sdcard/0my_files/tmp/xxx/ -1
          #or $ ls /sdcard/0my_files/tmp/xxx/auto/ -1
          #一是 手动备份
          #一是 自动备份
        config.xml
        myBookSearchHistory.json
        myBookShelf.json
        myBookSource.json
        myTxtChapterRule.json
        ==========================
        ==========================
        ==========================
        config.xml
            <string name="backupPath">content://com.android.externalstorage.documents/tree/primary%3A0my_files%2Ftmp%2Fxxx</string>
        myBookSearchHistory.json
        myBookShelf.json
            书架-次序，最后阅读章节
            :: [{???}]
            [
              {
              "allowUpdate": false,
              "bookInfoBean": {
                "author": "",
                "coverUrl": "",
                "finalRefreshData": 1627725740000,
                "name": "实习书记",
                "noteUrl": "/storage/72A2-151D/000edt/0my_files/book_txt/小说天堂txt/重命名/小说天堂txt-9/《实习书记》.txt",
                "origin": "本地",
                "tag": "loc_book"
              },
              "chapterListSize": 0,
              "durChapter": 0,
              "durChapterPage": 0,
              "finalDate": 1634428021518,
              "finalRefreshData": 1634428021518,
              "group": 3,
              "hasUpdate": true,
              "isLoading": false,
              "newChapters": 0,
              "noteUrl": "/storage/72A2-151D/000edt/0my_files/book_txt/小说天堂txt/重命名/小说天堂txt-9/《实习书记》.txt",
              "replaceEnable": false,
              "serialNumber": 0,
              "tag": "loc_book",
              "useReplaceRule": true
              },
              {
              "allowUpdate": false,
              "bookInfoBean": {
                "author": "再入江湖",
                "coverUrl": "",
                "finalRefreshData": 1612880284000,
                "name": "纵横天下从铁布衫开始",
                "noteUrl": "/storage/emulated/0/0my_files/novel/《纵横天下从铁布衫开始》（校对版全本）作者：再入江湖.txt",
                "origin": "本地",
                "tag": "loc_book"
              },
              "chapterListSize": 522,
              "durChapter": 521,
              "durChapterName": "第五百二十一章 新的传说（大结局）",
              "durChapterPage": 58,
              "finalDate": 1613628671031,
              "finalRefreshData": 1612881022477,
              "group": 3,
              "hasUpdate": false,
              "isLoading": false,
              "lastChapterName": "第五百二十一章 新的传说（大结局）",
              "newChapters": 0,
              "noteUrl": "/storage/emulated/0/0my_files/novel/《纵横天下从铁布衫开始》（校对版全本）作者：再入江湖.txt",
              "replaceEnable": false,
              "serialNumber": 0,
              "tag": "loc_book",
              "useReplaceRule": true
              }
            ]
        myBookSource.json
            网文网站，下载/爬虫抓取 格式
        myTxtChapterRule.json
            章节标题，正则表达式
        ==========================
        e /sdcard/0my_files/tmp/xxx/阅读app备份json/README.txt
        ==========================
        ==========================
        ==========================



