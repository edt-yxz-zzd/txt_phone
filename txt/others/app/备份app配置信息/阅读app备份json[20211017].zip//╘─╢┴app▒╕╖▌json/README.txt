
e /sdcard/0my_files/tmp/xxx/阅读app备份json/README.txt


阅读
  轻阅 @com.feng.monkeybook
    # 本地txt小说 + 联网书源离线下载
    #https://github.com/gedoor/MyBookshelf ??
    # 可替代 小说阅读器（亮度无法降至零！）
    # 问题是：下载的小说 是 从网页爬的，速度慢，只有25kB/s；质量没保证，一千章就是一千文本文件，1156章*6kB ?=? 17MB by 『du -d 0 -h .』 ???
    #轻阅 离线下载路径: '/sdcard/Android/data/com.feng.monkeybook/files/book_cache/修真者在异世-httpswwwgeilwxcc/00000-第一章  超级散魔.nb'
    #轻阅 书源 文件路径: /sdcard/YueDu/auto/myBookSource.json
      $ ls /sdcard/YueDu/auto/
      config.xml
      myBookSearchHistory.json
      myBookShelf.json
      myBookSource.json
      myTxtChapterRule.json
    轻阅 轻量级阅读工具（不是 轻阅影视）
      旧版:http://m.58xuexi.com/app/v195389.html
      轻阅v10047
        <<== https://www.xiaozhongjishu.com/app/656.html/
          <<== 小众技术工具库:https://www.xiaozhongjishu.com/
  阅读 @com.gedoor.monkeybook
    # 这才是『轻阅』的原版，但没有书源，看来需要从 轻阅 复制 书源，见上面『轻阅 书源 文件路径』
    #
      官网:https://github.com/gedoor/MyBookshelf
          <<== 小众技术工具库:https://www.xiaozhongjishu.com/
    #！！！备份！！！
    #   左上角 竖排三横 -> 备份 [初始化 选择文件夹，以后 默认...]
    #   /sdcard/0my_files/tmp/xxx/
        $ ls /sdcard/0my_files/tmp/xxx/ -1
        config.xml
        myBookSearchHistory.json
        myBookShelf.json
        myBookSource.json
        myTxtChapterRule.json
        ==========================
        ==========================
        ==========================
        config.xml
            <string name="backupPath">content://com.android.externalstorage.documents/tree/primary%3A0my_files%2Ftmp%2Fxxx</string>
        myBookSearchHistory.json
        myBookShelf.json
            书架-次序，最后阅读章节
            :: [{???}]
            [
              {
              "allowUpdate": false,
              "bookInfoBean": {
                "author": "",
                "coverUrl": "",
                "finalRefreshData": 1627725740000,
                "name": "实习书记",
                "noteUrl": "/storage/72A2-151D/000edt/0my_files/book_txt/小说天堂txt/重命名/小说天堂txt-9/《实习书记》.txt",
                "origin": "本地",
                "tag": "loc_book"
              },
              "chapterListSize": 0,
              "durChapter": 0,
              "durChapterPage": 0,
              "finalDate": 1634428021518,
              "finalRefreshData": 1634428021518,
              "group": 3,
              "hasUpdate": true,
              "isLoading": false,
              "newChapters": 0,
              "noteUrl": "/storage/72A2-151D/000edt/0my_files/book_txt/小说天堂txt/重命名/小说天堂txt-9/《实习书记》.txt",
              "replaceEnable": false,
              "serialNumber": 0,
              "tag": "loc_book",
              "useReplaceRule": true
              },
              {
              "allowUpdate": false,
              "bookInfoBean": {
                "author": "再入江湖",
                "coverUrl": "",
                "finalRefreshData": 1612880284000,
                "name": "纵横天下从铁布衫开始",
                "noteUrl": "/storage/emulated/0/0my_files/novel/《纵横天下从铁布衫开始》（校对版全本）作者：再入江湖.txt",
                "origin": "本地",
                "tag": "loc_book"
              },
              "chapterListSize": 522,
              "durChapter": 521,
              "durChapterName": "第五百二十一章 新的传说（大结局）",
              "durChapterPage": 58,
              "finalDate": 1613628671031,
              "finalRefreshData": 1612881022477,
              "group": 3,
              "hasUpdate": false,
              "isLoading": false,
              "lastChapterName": "第五百二十一章 新的传说（大结局）",
              "newChapters": 0,
              "noteUrl": "/storage/emulated/0/0my_files/novel/《纵横天下从铁布衫开始》（校对版全本）作者：再入江湖.txt",
              "replaceEnable": false,
              "serialNumber": 0,
              "tag": "loc_book",
              "useReplaceRule": true
              }
            ]
        myBookSource.json
            网文网站，下载/爬虫抓取 格式
        myTxtChapterRule.json
            章节标题，正则表达式
        ==========================
        e /sdcard/0my_files/tmp/xxx/阅读app备份json/README.txt
        ==========================
        ==========================
        ==========================



