var_log_apt__20220429

搜 dpkg ... log
  [[
  e /sdcard/Download/downs4termux/other-urls.txt
  e script/20220427_fix_termux.py
  e others/app/termux/apt_pkg.txt
  e others/app/termux/apt_update_fail__solved.txt
  e TODO.txt
  ]]==>> /var/log/dpkg.log
    termux下没找到对应的

  $ ls ~/../usr/var/log/ -1
    alternatives.log
    apt
  view ~/../usr/var/log/alternatives.log
    没什么东西
  ls ~/../usr/var/log/apt/ -1
    eipp.log.xz
    history.log
    term.log
  view ~/../usr/var/log/apt/history.log
    命令执行结果？
  view ~/../usr/var/log/apt/term.log
    终端输出的全部历史？
  mkdir /sdcard/0my_files/tmp/var_log_apt__20220429/
  cp -r ~/../usr/var/log/apt/  /sdcard/0my_files/tmp/var_log_apt__20220429/
  e /sdcard/0my_files/tmp/var_log_apt__20220429/README.txt


